# RuFilmTV 2.9

Android / Android TV / Google TV WebView client for https://rufilmtv.tv.

## 2.9 changes
- Improved remote-control focus visibility and initial focus.
- Hides the unstyled WebView until the app skin has been injected, preventing the original-site flash on first launch.
- Removed the remote Google Fonts import from the startup skin.
- Added player preference: built-in, MX Player, VLC, or ask each time.
- Added a best-effort JavaScript fullscreen hook that passes a direct HTML5 video URL to the selected external player.
- Added Android TV banner metadata and a landscape TV banner; retained adaptive Android launcher icons and added a monochrome layer.
- Kept the built-in fullscreen player as fallback.

## External-player limitations
External playback works only when the page exposes a direct HTTP(S) HTML5 video URL. DRM, blob URLs, MediaSource streams, iframe-only players, site cookies, or required request headers may prevent external playback. In those cases use the built-in player. The fullscreen hook is best-effort and must be tested against the site's actual player.

## Build
Requires JDK 17, Android SDK 35 and Gradle 8.9. Run `gradle assembleDebug`.
