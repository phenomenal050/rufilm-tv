package tv.rufilm.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Lightweight ABP-style network filter for WebView. It intentionally does not block media by type. */
public final class AdBlocker {
    private static final String PREFS = "rufilm_adblock";
    private static final String KEY_RULES = "rules_v1";
    private static final String KEY_UPDATED = "updated_at";
    private static final long UPDATE_INTERVAL = 24L * 60L * 60L * 1000L;
    private static final String[] LISTS = {
        "https://easylist.to/easylist/easylist.txt",
        "https://easylist-downloads.adblockplus.org/ruadlist+easylist.txt"
    };
    private static final String[] BUILTIN_DOMAINS = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "adnxs.com", "adfox.ru", "yandexadexchange.net", "taboola.com", "outbrain.com",
        "criteo.com", "rubiconproject.com", "pubmatic.com", "openx.net", "smartadserver.com",
        "adform.net", "rtbhouse.com", "mgid.com", "teads.tv", "exoclick.com", "popads.net",
        "propellerads.com", "trafficjunky.net", "ads kaspi.kz", "ads.kaspi.kz", "ad.kaspi.kz",
        "promo.kaspi.kz", "banner.kaspi.kz"
    };
    private final SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Set<String> domains = Collections.synchronizedSet(new HashSet<String>());
    private final Set<String> paths = Collections.synchronizedSet(new HashSet<String>());
    private final Set<String> exceptions = Collections.synchronizedSet(new HashSet<String>());
    private volatile boolean updating;

    public AdBlocker(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        for (String d : BUILTIN_DOMAINS) if (!d.contains(" ")) domains.add(d);
        // Parse potentially large filter lists away from the UI thread. The built-in
        // domain rules above are available immediately while cached/asset rules load.
        executor.execute(() -> {
            loadRules(prefs.getString(KEY_RULES, ""));
            try (InputStream in = context.getAssets().open("adblock-base.txt")) {
                loadRules(readAll(in));
            } catch (Exception ignored) { }
        });
    }

    public boolean shouldBlock(String rawUrl) {
        if (rawUrl == null) return false;
        Uri uri;
        try { uri = Uri.parse(rawUrl); } catch (Exception e) { return false; }
        String host = uri.getHost();
        if (host == null) return false;
        host = host.toLowerCase(Locale.ROOT);
        // Never apply generic network rules to the cinema's own origin.
        if (host.equals("rufilmtv.tv") || host.endsWith(".rufilmtv.tv")) return false;
        String full = rawUrl.toLowerCase(Locale.ROOT);
        String path = uri.getEncodedPath() == null ? "" : uri.getEncodedPath().toLowerCase(Locale.ROOT);
        synchronized (exceptions) {
            for (String allowed : exceptions) if (host.equals(allowed) || host.endsWith("." + allowed)) return false;
        }
        synchronized (domains) {
            for (String domain : domains) if (host.equals(domain) || host.endsWith("." + domain)) return true;
        }
        // Kaspi first-party pages remain available; only clear ad-specific endpoints are filtered.
        if (host.equals("kaspi.kz") || host.endsWith(".kaspi.kz")) {
            if (host.startsWith("ads.") || host.startsWith("ad.") || host.startsWith("promo.") || host.startsWith("banner.")) return true;
            if (path.contains("/advert/ads/") || path.contains("/ads/banner/") || path.contains("/advertising/") || path.contains("/adserver/")) return true;
        }
        synchronized (paths) {
            for (String rulePath : paths) if (full.contains(rulePath)) return true;
        }
        return path.contains("/adserver/") || path.contains("/advertisement/") || path.contains("/banner-ad/")
            || path.contains("/adsbygoogle/") || path.equals("/ads") || path.startsWith("/ads/");
    }

    public long getLastUpdated() { return prefs.getLong(KEY_UPDATED, 0L); }
    public boolean isUpdating() { return updating; }

    public void updateIfNeeded(final Context context, final Runnable finished) {
        if (updating || System.currentTimeMillis() - getLastUpdated() < UPDATE_INTERVAL) return;
        update(context, finished);
    }

    public void update(final Context context, final Runnable finished) {
        if (updating) return;
        updating = true;
        executor.execute(() -> {
            StringBuilder combined = new StringBuilder();
            int successes = 0;
            for (String list : LISTS) {
                HttpURLConnection connection = null;
                try {
                    connection = (HttpURLConnection) new URL(list).openConnection();
                    connection.setConnectTimeout(12000);
                    connection.setReadTimeout(18000);
                    connection.setRequestProperty("User-Agent", "RuFilmTV/2.8 AdFilter");
                    connection.setInstanceFollowRedirects(true);
                    if (connection.getResponseCode() == 200) {
                        try (InputStream in = connection.getInputStream()) {
                            String data = readAll(in);
                            if (data.length() > 100) { combined.append(data).append('\n'); successes++; }
                        }
                    }
                } catch (Exception ignored) {
                } finally { if (connection != null) connection.disconnect(); }
            }
            if (successes > 0) {
                String data = combined.toString();
                prefs.edit().putString(KEY_RULES, data).putLong(KEY_UPDATED, System.currentTimeMillis()).apply();
                clearDynamicRules();
                loadRules(data);
            }
            updating = false;
            if (finished != null) new Handler(Looper.getMainLooper()).post(finished);
        });
    }

    private void clearDynamicRules() {
        domains.clear(); paths.clear(); exceptions.clear();
        for (String d : BUILTIN_DOMAINS) if (!d.contains(" ")) domains.add(d);
    }

    private void loadRules(String data) {
        if (data == null || data.isEmpty()) return;
        // String.split/replaceAll compile regular expressions and were causing
        // long pauses on low-power TV boxes with large EasyList snapshots.
        try (BufferedReader reader = new BufferedReader(new StringReader(data))) {
            String raw;
            while ((raw = reader.readLine()) != null) {
                String line = raw.trim();
                if (line.isEmpty() || line.startsWith("!") || line.startsWith("[") || line.startsWith("#")) continue;
                boolean exception = line.startsWith("@@");
                if (exception) line = line.substring(2);
                int options = line.indexOf('$');
                if (options >= 0) line = line.substring(0, options);
                if (line.startsWith("||")) {
                    String host = line.substring(2);
                    int end = host.indexOf('^');
                    if (end < 0) end = host.indexOf('/');
                    if (end >= 0) host = host.substring(0, end);
                    host = normalizeHost(host);
                    if (host.indexOf('.') >= 0 && host.length() < 255) {
                        if (exception) exceptions.add(host); else domains.add(host);
                    }
                } else if (line.startsWith("/") && line.indexOf('*') < 0 && line.indexOf('^') < 0) {
                    String p = line.toLowerCase(Locale.ROOT);
                    if (p.length() > 3 && p.length() < 180) paths.add(p);
                }
            }
        } catch (Exception ignored) { }
    }

    private static String normalizeHost(String value) {
        StringBuilder out = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
                    || (c >= '0' && c <= '9') || c == '.' || c == '-') {
                out.append(Character.toLowerCase(c));
            }
        }
        return out.toString();
    }

    private static String readAll(InputStream in) throws Exception {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line; while ((line = reader.readLine()) != null) { out.append(line).append('\n'); if (out.length() > 12_000_000) break; }
        }
        return out.toString();
    }
}
