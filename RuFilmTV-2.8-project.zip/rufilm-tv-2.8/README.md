# RuFilmTV 2.8

Android / Android TV / Google TV WebView client for https://rufilmtv.tv.

## 2.8
- Updated launcher icon: cream/ivory, black film/play mark and black `RuFilm` with red `TV` (concept 13).
- Added an ABP-style network filter with built-in rules and daily refresh of EasyList and RU AdList.
- Added a manual filter refresh control and retained the last successful downloaded lists when a refresh fails.
- Added conservative cosmetic hiding for clearly labelled ad/promotional containers, including Kaspi-specific ad endpoints and embeds. Ordinary Kaspi pages are not blocked wholesale.
- Added fullscreen handling for HTML5/WebView players, including system UI hiding and back-button exit.

## Ad-filter limitations
The built-in parser supports domain and simple path rules from ABP-style lists; it is not a complete Adblock Plus engine and does not implement every option, regular expression, scriptlet or cosmetic rule. Some ads may remain, especially ads rendered inside a site's own video stream. Broadly blocking Kaspi itself is deliberately avoided to preserve ordinary pages and login/navigation.

## Build
Requires JDK 17, Android SDK 35 and Gradle 8.9. Run `gradle assembleDebug`.
