# Rufilm TV 2.6

Android / Android TV / Google TV WebView client for https://rufilmtv.tv.

## 2.6 changes
- Dark graphite styling for film and series description sections.
- Red accent color across the native app controls.
- Improved best-effort hiding of clearly labelled advertising elements, including elements inserted after page load.
- Keeps ordinary media frames and video players untouched.

Ad suppression is limited to identifiable ad containers and known advertising iframe hosts. Ads rendered inside a site's own media player or unlabelled content may still appear.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK installed.


## Иконка приложения
Добавлена фирменная чёрно-красная иконка Rufilm TV с надписью и адаптивными ресурсами Android.


## Rufilm TV 2.7

- Усиленная фильтрация известных рекламных сетей на уровне WebView-запросов.
- Дополнительное скрытие рекламных контейнеров и iframe в DOM.
- Домены видеоплееров и обычные медиа-запросы намеренно не блокируются общими правилами.
- Фильтрация best-effort: реклама внутри видеопотока или неизвестного встроенного плеера может оставаться.
