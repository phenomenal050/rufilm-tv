package tv.rufilm.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.webkit.JavascriptInterface;
import android.view.KeyEvent;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.os.Build;
import android.widget.FrameLayout;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.net.Uri;
import java.io.ByteArrayInputStream;
import java.util.Locale;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Bitmap;

public class MainActivity extends Activity {
    private static final String BASE = "https://rufilmtv.tv";
    private WebView web;
    private AdBlocker adBlocker;
    private View rootLayout, customView;
    private FrameLayout fullscreenContainer;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private int previousSystemUiVisibility;
    private TextView pageTitle, loading;
    private Button[] tabs = new Button[6];
    private final String[] labels = {"Главная","Фильмы","Сериалы","Мультфильмы","ТВ","Трейлеры"};
    private final String[] paths = {"/","/films","/serials","/cartoon","/tv-show","/trailers"};
    private int active = 0;
    private final int bg = Color.rgb(17,19,22), panel = Color.rgb(33,36,40),
        accent = Color.rgb(215,52,69), muted = Color.rgb(173,176,183);

    private boolean cleanMode = true;
    private Button cleanButton, filterButton, playerButton;
    private SharedPreferences prefs;
    private String externalPlayer = "builtin";
    private boolean firstPageReady = false;
    private boolean externalLaunchPending = false;
    private static final String PREFS = "rufilm_tv_settings";
    private final String skin = "(function(){"
      + "var css=`"
      + ":root{color-scheme:dark;background:#151719;--rf-red:#e53945;}"
      + "html,body{background:#151719!important;color:#f1eeee!important;font-family:Roboto,Arial,sans-serif!important;}"
      + "body{margin:0!important;padding:10px!important;}"
      + "a{color:#ff7780!important;text-decoration:none!important;}"
      + "a:focus,button:focus,input:focus,select:focus,[tabindex]:focus{outline:3px solid #ff6675!important;outline-offset:2px!important;}"
      + "h1,h2,h3,h4,h5,h6,strong,b{color:#fff!important;}"
      + "input,select,textarea{background:#25292d!important;color:#fff!important;border:1px solid #554047!important;border-radius:8px!important;padding:9px!important;}"
      + "button,input[type=submit],input[type=button]{background:#b9273d!important;color:#fff!important;border:0!important;border-radius:8px!important;padding:8px 12px!important;}"
      + "article,.shortstory,.short-story,.movie-item,.film-item,.serial-item,.item,.post,.news-item,.story,.content-item,.movie,.film,.serial,.card{background:#24282c!important;color:#f1edef!important;border:1px solid #3b3438!important;border-radius:10px!important;padding:9px!important;margin:8px 0!important;}"
      + ".shortstory img,.short-story img,.movie-item img,.film-item img,.serial-item img,.item img,.post img,article img,.poster img{border-radius:7px!important;object-fit:cover!important;}"
      + ".content,#content,.main-content,#main,.main,.page-content,.container,.wrapper{background:transparent!important;color:#f4f1f2!important;max-width:100%!important;}"
      + "table,td,th{background:#25292d!important;color:#eee!important;border-color:#3a3437!important;}"
      + "iframe,video{max-width:100%!important;background:#080808!important;}"
      + ".pagination a,.pages a,.navigation a,.pagi a{background:#292d31!important;border-radius:7px!important;padding:6px 9px!important;margin:2px!important;}"
      + ".active,.current,.pagination .active{background:#b9273d!important;color:white!important;}"
      + "header,#header,.header,.site-header,.header-top,.header-menu,.top-menu,#footer,.footer,footer,.site-footer,#sidebar,.sidebar{display:none!important;}"
      + "html.rf-clean .ads,html.rf-clean .ad,html.rf-clean .advert,html.rf-clean .advertisement,html.rf-clean .banner-ad,html.rf-clean .ad-container,html.rf-clean .ad-wrapper,html.rf-clean .ad-slot,html.rf-clean .ads-container,html.rf-clean [class*=advert],html.rf-clean [id*=advert],html.rf-clean [class*=adsbygoogle],html.rf-clean [id*=yandex_rtb],html.rf-clean [class*=yandex-rtb],html.rf-clean [data-ad],html.rf-clean [data-ad-slot],html.rf-clean [data-advertisement],html.rf-clean ins.adsbygoogle,html.rf-clean .google-auto-placed,html.rf-clean iframe[src*=doubleclick],html.rf-clean iframe[src*=googlesyndication],html.rf-clean iframe[src*=googleadservices],html.rf-clean iframe[src*=adfox],html.rf-clean iframe[src*=yandexadexchange],html.rf-clean iframe[src*=taboola],html.rf-clean iframe[src*=outbrain],html.rf-clean iframe[src*=kaspi.kz],html.rf-clean [class*=promo-banner],html.rf-clean [id*=promo-banner]{display:none!important;}"
      + "html body .description,html body .entry-content,html body .entry-summary,html body .post-content,html body .fullstory,html body .full-story,html body .full-text,html body .film-description,html body .serial-description,html body .movie-description,html body .detail-description{background:#24282c!important;color:#eee9eb!important;border:1px solid #40383c!important;border-radius:10px!important;padding:12px!important;}"
      + "html body .description p,html body .entry-content p,html body .post-content p,html body .fullstory p,html body .full-story p,html body .full-text p{color:#d4cfd1!important;line-height:1.5!important;}"
      + "html body .description a,html body .entry-content a{color:#ff7882!important;}"
      + "body>div{max-width:100%!important;}"
      + "`;var old=document.getElementById('rufilm-native-skin');if(old)old.remove();var st=document.createElement('style');st.id='rufilm-native-skin';st.textContent=css;(document.head||document.documentElement).appendChild(st);"
      + "document.documentElement.classList.toggle('rf-clean',true);"
      + "})();";

    // ABP-style network filtering; the cinema origin and ordinary media requests are exempt.
    private boolean isAdRequest(String rawUrl) {
        return adBlocker != null && adBlocker.shouldBlock(rawUrl);
    }

    private WebResourceResponse emptyBlockedResponse() {
        return new WebResourceResponse("text/plain", "UTF-8",
            new ByteArrayInputStream(new byte[0]));
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        externalPlayer = prefs.getString("external_player", "ask");
        adBlocker = new AdBlocker(this);
        adBlocker.updateIfNeeded(this, null);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
        if (state != null) web.restoreState(state); else web.loadUrl(BASE + "/");
    }
    private GradientDrawable shape(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private Button button(String s,boolean primary){
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(11);
        b.setTextColor(Color.WHITE);b.setBackground(shape(primary?accent:panel,13));
        b.setMinHeight(0);b.setMinimumHeight(0);b.setMinWidth(0);b.setStateListAnimator(null);
        b.setFocusable(true);b.setFocusableInTouchMode(true);
        b.setOnFocusChangeListener((v, hasFocus) -> {
            v.setScaleX(hasFocus ? 1.045f : 1.0f);
            v.setScaleY(hasFocus ? 1.045f : 1.0f);
            v.setElevation(hasFocus ? dp(8) : 0);
            v.setBackground(shape(hasFocus ? accent : (primary ? accent : panel), 13));
        });
        return b;
    }
    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        rootLayout=root;
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18),dp(8),dp(14),dp(8));header.setBackgroundColor(bg);
        LinearLayout brandBox=new LinearLayout(this);brandBox.setOrientation(LinearLayout.VERTICAL);
        brandBox.addView(text("RU FILM",23,Color.WHITE,true));
        brandBox.addView(text("TV  •  YOUR CINEMA",9,0xffff7b86,true));
        header.addView(brandBox,new LinearLayout.LayoutParams(0,-2,1));
        cleanButton=button("Чистый ✓",true);
        cleanButton.setTextSize(10);
        cleanButton.setOnClickListener(v->toggleCleanMode());
        header.addView(cleanButton,new LinearLayout.LayoutParams(dp(78),dp(42)));
        filterButton=button("Фильтры",false);filterButton.setTextSize(9);
        filterButton.setOnClickListener(v->updateFilterLists());
        LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(dp(70),dp(42));fp.leftMargin=dp(5);header.addView(filterButton,fp);
        playerButton=button("Плеер",false);playerButton.setTextSize(9);
        playerButton.setOnClickListener(v->showPlayerDialog());
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(66),dp(42));pp.leftMargin=dp(5);header.addView(playerButton,pp);
        Button search=button("⌕",true);search.setTextSize(20);search.setOnClickListener(v->searchDialog());
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(46),dp(42));sp.leftMargin=dp(7);
        header.addView(search,sp);
        root.addView(header);

        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16),dp(4),dp(16),dp(8));bar.setBackgroundColor(bg);
        pageTitle=text("Сейчас смотрят",15,Color.WHITE,true);
        bar.addView(pageTitle,new LinearLayout.LayoutParams(0,dp(30),1));
        loading=text("● ONLINE",9,0xffff7882,true);bar.addView(loading);
        root.addView(bar);

        web=new WebView(this);web.setBackgroundColor(bg);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setVisibility(View.INVISIBLE);
        // Keep the mouse arrow visible over the WebView video surface.
        if (Build.VERSION.SDK_INT >= 24) {
            web.setOnHoverListener((v, event) -> {
                if (event.getAction() == MotionEvent.ACTION_HOVER_ENTER
                        || event.getAction() == MotionEvent.ACTION_HOVER_MOVE) {
                    v.setPointerIcon(PointerIcon.getSystemIcon(MainActivity.this, PointerIcon.TYPE_ARROW));
                }
                return false;
            });
        }
        web.getSettings().setJavaScriptEnabled(true);
        web.addJavascriptInterface(new PlayerBridge(), "RuFilmPlayer");
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.getSettings().setLoadWithOverviewMode(true);
        web.getSettings().setUseWideViewPort(true);
        web.getSettings().setSupportMultipleWindows(false);
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onConsoleMessage(android.webkit.ConsoleMessage message) {
                android.util.Log.d("RuFilmTV", "JS " + message.message() + " @" + message.lineNumber());
                return true;
            }
            @Override public void onShowCustomView(View view, CustomViewCallback callback){
                if(customView!=null){callback.onCustomViewHidden();return;}
                customView=view;customViewCallback=callback;
                if (Build.VERSION.SDK_INT >= 24) {
                    view.setOnHoverListener((v, event) -> {
                        if (event.getAction() == MotionEvent.ACTION_HOVER_ENTER
                                || event.getAction() == MotionEvent.ACTION_HOVER_MOVE) {
                            v.setPointerIcon(PointerIcon.getSystemIcon(MainActivity.this, PointerIcon.TYPE_ARROW));
                        }
                        return false;
                    });
                }
                android.view.View decor=getWindow().getDecorView();
                previousSystemUiVisibility=decor.getSystemUiVisibility();
                fullscreenContainer=new FrameLayout(MainActivity.this);
                fullscreenContainer.setBackgroundColor(Color.BLACK);
                fullscreenContainer.addView(view,new FrameLayout.LayoutParams(-1,-1));
                ((ViewGroup)decor).addView(fullscreenContainer,new ViewGroup.LayoutParams(-1,-1));
                rootLayout.setVisibility(View.GONE);
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
            @Override public void onHideCustomView(){hideCustomView();}
            @Override public void onProgressChanged(WebView view,int progress){
                loading.setText(progress<100?"● ЗАГРУЗКА "+progress+"%":"● ONLINE");
            }
        });
        web.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
                if (request != null && isAdRequest(request.getUrl().toString()))
                    return emptyBlockedResponse();
                return super.shouldInterceptRequest(view, request);
            }
            @SuppressWarnings("deprecation")
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, String url){
                if (isAdRequest(url)) return emptyBlockedResponse();
                return super.shouldInterceptRequest(view, url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                String host=request.getUrl().getHost();
                if(host==null)return false;
                // Keep Rufilm pages and embedded media inside the app.
                return false;
            }
            @Override public void onPageStarted(WebView view,String url,Bitmap icon){
                pageTitle.setText(titleFor(url));
                firstPageReady = true;
                view.setVisibility(View.VISIBLE);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    firstPageReady = true;
                    view.setVisibility(View.VISIBLE);
                    loading.setText("● НЕТ СВЯЗИ");
                }
            }
            @Override public void onPageFinished(WebView view,String url){
                android.util.Log.i("RuFilmTV", "Page finished: " + url);
                pageTitle.setText(titleFor(url));
                view.evaluateJavascript(skin, ignored -> {
                    injectExternalPlayerHook(view);
                    applyCleanMode();
                    view.setVisibility(View.VISIBLE);
                });
            }
            @Override public boolean onRenderProcessGone(WebView view, android.webkit.RenderProcessGoneDetail detail) {
                android.util.Log.e("RuFilmTV", "WebView renderer gone; crashed=" + detail.didCrash());
                loading.setText("● ОШИБКА WEBVIEW — ПЕРЕЗАПУСТИТЕ ПРИЛОЖЕНИЕ");
                view.setVisibility(View.VISIBLE);
                return true;
            }
        });
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(4),dp(7),dp(4),dp(7));nav.setBackgroundColor(panel);
        for(int i=0;i<labels.length;i++){
            final int index=i;Button b=button(labels[i],false);tabs[i]=b;b.setPadding(dp(1),dp(8),dp(1),dp(8));
            b.setOnClickListener(v->navigate(index));nav.addView(b,new LinearLayout.LayoutParams(0,dp(50),1));
        }
        root.addView(nav);setContentView(root);updateTabs();
    }

    private void showPlayerDialog() {
        String[] names = {"Встроенный плеер", "MX Player", "VLC", "Спрашивать каждый раз"};
        String[] values = {"builtin", "mx", "vlc", "ask"};
        int checked = 0;
        for (int i=0;i<values.length;i++) if (values[i].equals(externalPlayer)) checked=i;
        new AlertDialog.Builder(this).setTitle("Видеоплеер")
            .setSingleChoiceItems(names, checked, (dialog, which) -> {
                externalPlayer = values[which];
                prefs.edit().putString("external_player", externalPlayer).apply();
                Toast.makeText(this, "Выбран режим: " + names[which], Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }).setNegativeButton("Закрыть", null).show();
    }

    private void injectExternalPlayerHook(WebView view) {
        String js = "(function(){if(window.__rfExternalHook)return;window.__rfExternalHook=true;"
          + "function launch(v){try{if(!v)return false;var u=v.currentSrc||v.src;if(!u)return false;"
          + "if(v.__rfSentUrl===u)return true;v.__rfSentUrl=u;"
          + "if(window.RuFilmPlayer&&window.RuFilmPlayer.isExternalEnabled()){window.RuFilmPlayer.openExternal(String(u));return true;}"
          + "}catch(e){}return false;}"
          + "function watch(v){if(!v||v.__rfWatched)return;v.__rfWatched=true;"
          + "v.addEventListener('playing',function(){setTimeout(function(){launch(v);},150);},true);"
          + "v.addEventListener('loadedmetadata',function(){if(v.paused===false)setTimeout(function(){launch(v);},150);},true);"
          + "}"
          + "function scan(){document.querySelectorAll('video').forEach(watch);}"
          + "function scanAdded(n){if(!n||n.nodeType!==1)return;if(n.tagName==='VIDEO')watch(n);if(n.querySelectorAll)n.querySelectorAll('video').forEach(watch);}"
          + "scan();new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(scanAdded);});}).observe(document.documentElement,{childList:true,subtree:true});"
          + "var p=Element.prototype.requestFullscreen;"
          + "if(p){Element.prototype.requestFullscreen=function(){var v=this.tagName==='VIDEO'?this:this.querySelector&&this.querySelector('video');"
          + "if(v)launch(v);return p.apply(this,arguments);};}"
          + "if(window.HTMLVideoElement&&HTMLVideoElement.prototype.webkitEnterFullscreen){"
          + "var old=HTMLVideoElement.prototype.webkitEnterFullscreen;"
          + "HTMLVideoElement.prototype.webkitEnterFullscreen=function(){if(launch(this))return;return old.apply(this,arguments);};}"
          + "document.addEventListener('fullscreenchange',function(){if(document.fullscreenElement){"
          + "var v=document.fullscreenElement.tagName==='VIDEO'?document.fullscreenElement:document.fullscreenElement.querySelector('video');if(v)launch(v);}},true);"
          + "})();";
        view.evaluateJavascript(js, null);
    }

    private class PlayerBridge {
        @JavascriptInterface public boolean isExternalEnabled() {
            if ("builtin".equals(externalPlayer)) return false;
            if ("ask".equals(externalPlayer)) return true;
            String pkg = "mx".equals(externalPlayer) ? "com.mxtech.videoplayer.ad" : "org.videolan.vlc";
            if ("mx".equals(externalPlayer)) {
                try { getPackageManager().getPackageInfo(pkg, 0); return true; }
                catch (Exception ignored) {
                    try { getPackageManager().getPackageInfo("com.mxtech.videoplayer.pro", 0); return true; }
                    catch (Exception ignoredAgain) { return false; }
                }
            }
            try { getPackageManager().getPackageInfo(pkg, 0); return true; }
            catch (Exception ignored) { return false; }
        }
        @JavascriptInterface public void openExternal(String rawUrl) {
            runOnUiThread(() -> launchExternalPlayer(rawUrl));
        }
    }

    private void launchExternalPlayer(String rawUrl) {
        if (externalLaunchPending || rawUrl == null || rawUrl.trim().isEmpty()) return;
        if ("builtin".equals(externalPlayer)) return;
        try {
            String pageHost = Uri.parse(web.getUrl()).getHost();
            if (pageHost == null || !(pageHost.equalsIgnoreCase("rufilmtv.tv") || pageHost.toLowerCase(Locale.ROOT).endsWith(".rufilmtv.tv"))) return;
        } catch (Exception ignored) { return; }
        Uri uri;
        try { uri = Uri.parse(rawUrl); } catch (Exception e) { return; }
        String scheme = uri.getScheme();
        if (!("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme))) return;
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "video/*");
        String pkg = null;
        if ("mx".equals(externalPlayer)) {
            pkg = "com.mxtech.videoplayer.ad";
            try { getPackageManager().getPackageInfo(pkg, 0); }
            catch (Exception ignored) { pkg = "com.mxtech.videoplayer.pro"; }
        } else if ("vlc".equals(externalPlayer)) pkg = "org.videolan.vlc";
        if (pkg != null) {
            intent.setPackage(pkg);
            if (intent.resolveActivity(getPackageManager()) == null) {
                Toast.makeText(this, pkg.startsWith("com.mxtech") ? "MX Player не установлен" : "VLC не установлен", Toast.LENGTH_LONG).show();
                return;
            }
        } else if ("ask".equals(externalPlayer)) {
            intent = Intent.createChooser(intent, "Открыть видео в…");
        } else {
            return;
        }
        try {
            externalLaunchPending = true;
            if (web != null) {
                web.evaluateJavascript("(function(){document.querySelectorAll('video').forEach(function(v){try{v.pause();}catch(e){}});})();", null);
            }
            startActivity(intent);
        } catch (Exception e) {
            externalLaunchPending = false;
            Toast.makeText(this, "Не удалось открыть видео во внешнем плеере", Toast.LENGTH_LONG).show();
        }
    }

    private void updateFilterLists(){
        if(adBlocker==null)return;
        if(adBlocker.isUpdating()){Toast.makeText(this,"Списки уже обновляются",Toast.LENGTH_SHORT).show();return;}
        filterButton.setEnabled(false);filterButton.setText("Обновление…");
        final long previousUpdate=adBlocker.getLastUpdated();
        adBlocker.update(this,()->{
            filterButton.setEnabled(true);filterButton.setText("Фильтры");
            if(web!=null)web.reload();
            Toast.makeText(this,adBlocker.getLastUpdated()>previousUpdate?"Списки рекламы обновлены":"Не удалось обновить списки; используются сохранённые правила",Toast.LENGTH_LONG).show();
        });
    }
    private void hideCustomView(){
        if(customView==null)return;
        android.view.View decor=getWindow().getDecorView();
        if(fullscreenContainer!=null){((ViewGroup)decor).removeView(fullscreenContainer);fullscreenContainer=null;}
        customView=null;rootLayout.setVisibility(View.VISIBLE);
        decor.setSystemUiVisibility(previousSystemUiVisibility);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if(customViewCallback!=null){customViewCallback.onCustomViewHidden();customViewCallback=null;}
    }
    private String titleFor(String url){
        if(url.contains("/films"))return "Фильмы";
        if(url.contains("/serials"))return "Сериалы";
        if(url.contains("/cartoon"))return "Мультфильмы";
        if(url.contains("/tv-show"))return "ТВ-передачи";
        if(url.contains("/trailers"))return "Трейлеры";
        return "Главная";
    }
    private void navigate(int i){active=i;updateTabs();web.loadUrl(BASE+paths[i]);pageTitle.setText(labels[i]);}
    private void updateTabs(){
        for(int i=0;i<tabs.length;i++)if(tabs[i]!=null){
            tabs[i].setTextColor(i==active?Color.WHITE:muted);
            tabs[i].setBackground(shape(i==active?accent:panel,12));
        }
    }
    private void applyCleanMode(){
        if(web!=null) web.evaluateJavascript("document.documentElement.classList.toggle('rf-clean',"+cleanMode+");",null);
        if(cleanButton!=null){
            cleanButton.setText(cleanMode?"Чистый ✓":"Чистый");
            cleanButton.setBackground(shape(cleanMode?0xffb9273d:panel,13));
        }
    }
    private void toggleCleanMode(){
        cleanMode=!cleanMode;
        applyCleanMode();
        Toast.makeText(this,cleanMode?"Чистый интерфейс включён":"Чистый интерфейс выключен",Toast.LENGTH_SHORT).show();
    }
    private void searchDialog(){
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Название фильма или сериала");
        input.setTextColor(Color.WHITE);input.setHintTextColor(muted);input.setPadding(dp(14),dp(8),dp(14),dp(8));
        input.setBackground(shape(panel,12));
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(18),dp(8),dp(18),dp(4));
        box.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Поиск Rufilm").setView(box)
          .setNegativeButton("Отмена",null).setPositiveButton("Найти",(d,w)->{
            String q=input.getText().toString().trim();
            if(!q.isEmpty()){
                String js="(function(){var x=document.querySelector('input[placeholder*=\\'Найти\\'],input[type=search],input[name=\\'story\\']');"
                  +"if(x){x.value="+org.json.JSONObject.quote(q)+";var f=x.closest('form');if(f)f.submit();else{var b=document.querySelector('button[type=submit],input[type=submit]');if(b)b.click();}}"
                  +"else{location.href='/index.php?do=search&subaction=search&story='+encodeURIComponent("+org.json.JSONObject.quote(q)+");}})();";
                web.evaluateJavascript(js,null);
            }
          }).create();
        dialog.show();dialog.getButton(-1).setTextColor(accent);dialog.getButton(-2).setTextColor(muted);
    }
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_UP && event.getKeyCode() == KeyEvent.KEYCODE_MENU) {
            showPlayerDialog(); return true;
        }
        return super.dispatchKeyEvent(event);
    }
    @Override public void onBackPressed(){if(customView!=null){hideCustomView();return;}if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onPause(){if(web!=null)web.onPause();super.onPause();}
    @Override protected void onResume(){super.onResume();externalLaunchPending=false;if(web!=null)web.onResume();}
}
