plugins { id("com.android.application") }
android {
    namespace = "tv.rufilm.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "tv.rufilm.app"
        minSdk = 23
        targetSdk = 28
        versionCode = 12
        versionName = "2.9"
    }
}
