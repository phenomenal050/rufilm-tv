# Rufilm TV 2.0
Native Android starter with graphite / premium cinema UI direction. Demo catalog, movie details, search, favorites, and focusable controls for Android TV remotes.

Real catalog data and playback require an authorized API/feed and licensed video URLs. No scraping or bypassing third-party protections is included.
