plugins { id("com.android.application") }

android {
    namespace = "tv.rufilm.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "tv.rufilm.app"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
