package tv.rufilm.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Bitmap;

public class MainActivity extends Activity {
    private static final String BASE = "https://rufilmtv.tv";
    private WebView web;
    private TextView pageTitle, loading;
    private Button[] tabs = new Button[6];
    private final String[] labels = {"Главная","Фильмы","Сериалы","Мультфильмы","ТВ","Трейлеры"};
    private final String[] paths = {"/","/films","/serials","/cartoon","/tv-show","/trailers"};
    private int active = 0;
    private final int bg = Color.rgb(14,16,21), panel = Color.rgb(25,28,36),
        accent = Color.rgb(119,91,255), muted = Color.rgb(164,170,184);

    private final String skin = "(function(){"
      + "var css=`"
      + "html,body{background:#0e1015!important;color:#f4f5fa!important;font-family:Arial, sans-serif!important;}"
      + "body{margin:0!important;padding:12px!important;}"
      + "a{color:#b9aaff!important;text-decoration:none!important;}"
      + "h1,h2,h3,h4{color:#fff!important;font-weight:800!important;letter-spacing:-.2px!important;}"
      + "p,li,small,span{color:inherit;}"
      + "input,select,textarea{background:#202430!important;color:#fff!important;border:1px solid #343b4b!important;border-radius:12px!important;padding:11px!important;}"
      + "button,input[type=submit]{background:#765bff!important;color:#fff!important;border:0!important;border-radius:12px!important;padding:10px 16px!important;}"
      + "img{max-width:100%;height:auto;}"
      + "article,.shortstory,.short-story,.movie-item,.film-item,.serial-item,.item,.post,.news-item,.story,.block,.box,.content-item{"
      + "background:#191d26!important;color:#e9eaf1!important;border:1px solid #292f3c!important;border-radius:18px!important;"
      + "padding:12px!important;margin:12px 0!important;box-shadow:0 8px 24px rgba(0,0,0,.22)!important;overflow:hidden!important;}"
      + ".shortstory img,.short-story img,.movie-item img,.film-item img,.serial-item img,.item img,.post img,article img{"
      + "border-radius:12px!important;object-fit:cover!important;}"
      + ".content,#content,.main-content,#main,.main,.page-content{background:transparent!important;color:#f4f5fa!important;max-width:100%!important;}"
      + "table{max-width:100%!important;color:#eee!important;}td,th{border-color:#303746!important;}"
      + "iframe,video{max-width:100%!important;border-radius:14px!important;}"
      + ".pagination a,.pages a,.navigation a{background:#222735!important;border-radius:10px!important;padding:8px 12px!important;margin:3px!important;}"
      + ".active,.current,.pagination .active{background:#765bff!important;color:white!important;}"
      + "header,#header,.header,.site-header,.header-top,.header-menu,.top-menu,#footer,.footer,footer,.site-footer,#sidebar,.sidebar{display:none!important;}"
      + "body>div{max-width:100%!important;}"
      + "@media(min-width:700px){.shortstory,.short-story,.movie-item,.film-item,.serial-item,.item,.post,article{display:block!important;}}"
      + "`;var old=document.getElementById('rufilm-native-skin');if(old)old.remove();"
      + "var s=document.createElement('style');s.id='rufilm-native-skin';s.textContent=css;document.head.appendChild(s);"
      + "})();";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        buildUi();
        if (state != null) web.restoreState(state); else web.loadUrl(BASE + "/");
    }
    private GradientDrawable shape(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;
    }
    private Button button(String s,boolean primary){
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(11);
        b.setTextColor(Color.WHITE);b.setBackground(shape(primary?accent:panel,13));
        b.setMinHeight(0);b.setMinimumHeight(0);b.setMinWidth(0);b.setStateListAnimator(null);
        b.setFocusable(true);b.setFocusableInTouchMode(true);return b;
    }
    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18),dp(8),dp(14),dp(8));header.setBackgroundColor(bg);
        LinearLayout brandBox=new LinearLayout(this);brandBox.setOrientation(LinearLayout.VERTICAL);
        brandBox.addView(text("RU FILM",23,Color.WHITE,true));
        brandBox.addView(text("TV  •  YOUR CINEMA",9,0xffa995ff,true));
        header.addView(brandBox,new LinearLayout.LayoutParams(0,-2,1));
        Button search=button("⌕  Поиск",true);search.setOnClickListener(v->searchDialog());
        header.addView(search,new LinearLayout.LayoutParams(dp(104),dp(42)));
        root.addView(header);

        LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16),dp(4),dp(16),dp(8));bar.setBackgroundColor(bg);
        pageTitle=text("Сейчас смотрят",15,Color.WHITE,true);
        bar.addView(pageTitle,new LinearLayout.LayoutParams(0,dp(30),1));
        loading=text("● ONLINE",9,0xff9c8aff,true);bar.addView(loading);
        root.addView(bar);

        web=new WebView(this);web.setBackgroundColor(bg);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.getSettings().setLoadWithOverviewMode(true);
        web.getSettings().setUseWideViewPort(true);
        web.getSettings().setSupportMultipleWindows(false);
        web.setWebChromeClient(new WebChromeClient(){
            @Override public void onProgressChanged(WebView view,int progress){
                loading.setText(progress<100?"● ЗАГРУЗКА "+progress+"%":"● ONLINE");
            }
        });
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                String host=request.getUrl().getHost();
                if(host==null)return false;
                // Keep Rufilm pages and embedded media inside the app.
                return false;
            }
            @Override public void onPageStarted(WebView view,String url,Bitmap icon){
                pageTitle.setText(titleFor(url));
            }
            @Override public void onPageFinished(WebView view,String url){
                pageTitle.setText(titleFor(url));
                view.evaluateJavascript(skin,null);
                // Reapply styling to elements inserted later by the site.
                view.evaluateJavascript("(function(){if(window.__rufilmObserver)return;window.__rufilmObserver=new MutationObserver(function(){var s=document.getElementById('rufilm-native-skin');if(!s){"+skin+"}});window.__rufilmObserver.observe(document.documentElement,{childList:true,subtree:true});})();",null);
            }
        });
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this);nav.setPadding(dp(4),dp(7),dp(4),dp(7));nav.setBackgroundColor(panel);
        for(int i=0;i<labels.length;i++){
            final int index=i;Button b=button(labels[i],false);tabs[i]=b;b.setPadding(dp(1),dp(8),dp(1),dp(8));
            b.setOnClickListener(v->navigate(index));nav.addView(b,new LinearLayout.LayoutParams(0,dp(50),1));
        }
        root.addView(nav);setContentView(root);updateTabs();
    }
    private String titleFor(String url){
        if(url.contains("/films"))return "Фильмы";
        if(url.contains("/serials"))return "Сериалы";
        if(url.contains("/cartoon"))return "Мультфильмы";
        if(url.contains("/tv-show"))return "ТВ-передачи";
        if(url.contains("/trailers"))return "Трейлеры";
        return "Главная";
    }
    private void navigate(int i){active=i;updateTabs();web.loadUrl(BASE+paths[i]);pageTitle.setText(labels[i]);}
    private void updateTabs(){
        for(int i=0;i<tabs.length;i++)if(tabs[i]!=null){
            tabs[i].setTextColor(i==active?Color.WHITE:muted);
            tabs[i].setBackground(shape(i==active?accent:panel,12));
        }
    }
    private void searchDialog(){
        EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Название фильма или сериала");
        input.setTextColor(Color.WHITE);input.setHintTextColor(muted);input.setPadding(dp(14),dp(8),dp(14),dp(8));
        input.setBackground(shape(panel,12));
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(18),dp(8),dp(18),dp(4));
        box.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Поиск Rufilm").setView(box)
          .setNegativeButton("Отмена",null).setPositiveButton("Найти",(d,w)->{
            String q=input.getText().toString().trim();
            if(!q.isEmpty()){
                String js="(function(){var x=document.querySelector('input[placeholder*=\\'Найти\\'],input[type=search],input[name=\\'story\\']');"
                  +"if(x){x.value="+org.json.JSONObject.quote(q)+";var f=x.closest('form');if(f)f.submit();else{var b=document.querySelector('button[type=submit],input[type=submit]');if(b)b.click();}}"
                  +"else{location.href='/index.php?do=search&subaction=search&story='+encodeURIComponent("+org.json.JSONObject.quote(q)+");}})();";
                web.evaluateJavascript(js,null);
            }
          }).create();
        dialog.show();dialog.getButton(-1).setTextColor(accent);dialog.getButton(-2).setTextColor(muted);
    }
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
